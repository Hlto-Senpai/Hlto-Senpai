package hosxboy;

import java.util.Scanner;

public class bsb3 {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("Fuqaro nechchi yoshda ?");
        int age=scan.nextInt();
        if (age<=7){
            System.out.println("bolalar bog’chsiga boradi");
        }
        else if (age >=7 && age <=18 ){
            System.out.println("maktabga boradi");
        }
        else if (age >=18 && age <=22){
            System.out.println(" Institutga boradi");
        }
        else if (age >=23 && age <=60){
            System.out.println("Ishga boradi");
        }
        else if (age>=60){
            System.out.println(" Nafaqada");
        }
    }
}
