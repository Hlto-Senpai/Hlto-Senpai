package hosxboy;

import java.util.Scanner;

public class bsb1 {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        double b1= scan.nextInt();
        double b2= scan.nextInt();
        double b3= scan.nextInt();
        double b4= scan.nextInt();
        double by= (b1+b2+b3+b4)/4;
        if (by==5){
            System.out.println("Bahoingiz" + " " + by);
            System.out.println("Siz kimyodan a`lo baho olgansiz");
        }
         else if ( by>=4){
            System.out.println(" Asil bahoingiz " + " " + by);
            System.out.println("Lekin Kimyo ustozingiz sizga 5 baho qo`ygan");
        }
        else if (by >=3){
            System.out.println(" Asil bahoingiz " + " " + by);
            System.out.println("Lekin Kimyo ustozingiz sizga 4 baho qo`ygan");
        }
        else {
            System.out.println(" Asil bahoingiz " + " " + by);
            System.out.println(" Sizga 2 dan baland baho qo`yib bo`lmadi");
        }
    }
}
