package hosxboy;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
               Scanner scan=new Scanner(System.in);
        System.out.println("Y nomalumni topish uchun x ga son kiriting");
               int x= scan.nextInt();
               int y= (int) (Math.pow(Math.sqrt(Math.pow(x,3)),3)+3 * Math.pow(x,6)-Math.pow(2,2*x));
        System.out.println("(Math.pow(Math.sqrt(Math.pow(3,3)),3)+3 * Math.pow(x,6)-Math.pow(2,2*x)) = " + " " +y);
            }
        }