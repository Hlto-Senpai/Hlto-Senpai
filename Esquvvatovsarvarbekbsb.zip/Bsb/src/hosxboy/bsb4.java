package hosxboy;
import java.util.Scanner;
public class bsb4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        char c = sc.next().charAt(0);
        if (c=='@' ){
            System.out.println("rubl");
        }
        if (c=='$' ){
            System.out.println("dollar");
        }
        if (c=='#' ){
            System.out.println("so`m");
        }
        if (c=='&' ){
            System.out.println("funt");
        }
        if (c=='%' ){
            System.out.println("iyena");
        }
        if (c=='!' ){
            System.out.println("dinor");
        }
        if (c=='*' ){
            System.out.println("krona");
        }
    }
}