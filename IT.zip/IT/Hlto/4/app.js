const btn = document.getElementsByTagName("button")
