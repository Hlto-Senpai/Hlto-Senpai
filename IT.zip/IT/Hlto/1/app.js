// let currentYear = 2022
// while(true){
// console.log(currentYear+5);
// }