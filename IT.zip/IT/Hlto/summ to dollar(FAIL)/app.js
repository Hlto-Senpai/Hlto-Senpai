let option = document.getElementById('name')
let summa = (document.getElementById('summa').value)

function Convert(){
    if (option = 'dollar'){
        let result = summa / 10860
        console.log(result)
    } else {
        let result = summa * 10860
        console.log(result)
    }
}
