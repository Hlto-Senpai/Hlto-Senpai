function test(){
x = document.getElementById("myTest").value
document.getElementById("demo").innerHTML = x
}