function myFunction(){
    let x = document.getElementById("it")
    let h1 = document.createElement("h1")
    document.body.append(h1)
    let block = document.getElementById("block")
    block.appendChild(h1)
    h1.innerHTML = x.value
    x.value = ""
}
function createTodo(){
let y = document.getElementById("mushuk")

}
console.log(location.reload)
