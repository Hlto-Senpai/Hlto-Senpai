function sayHellow(){
    console.log('first function');
}
sayHellow()