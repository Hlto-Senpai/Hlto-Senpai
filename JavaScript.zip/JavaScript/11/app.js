let btn = document.createElement("button")
document.body.append(btn)
btn.textContent = "Click me"

btn.addEventListener('click',  () =>{
let img = document.createElement("img")
img.setAttribute("src", "https://www.ru.nl/publish/pages/1031567/nature_1.png")
document.body.append(img)
})
