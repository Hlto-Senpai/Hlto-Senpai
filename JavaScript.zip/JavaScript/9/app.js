function createUser(job, salary){
    const user = {
        job,
        salary,
    }
return user
}
const user1 = createUser('javascript', '3000$')
console.log(user1)
const user2 = createUser('python', '2000$')
console.log(user2)