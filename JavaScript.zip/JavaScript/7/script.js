let x = document.getElementById('p')
function foo(){
    x.style.color = 'red'
    if( x = 'red')
    {
        x.style.color = 'yellow'
    
    }
    
}
