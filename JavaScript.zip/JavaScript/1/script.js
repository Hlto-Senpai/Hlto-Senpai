var start = 'hello js'
document.write(start)

let end = 'bye js'
document.write(end)
