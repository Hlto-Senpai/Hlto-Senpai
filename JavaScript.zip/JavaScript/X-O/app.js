let boxes = document.querySelector(".box")

box





// let belgi = 'x'

// function Game() {

// }

// function zero() {
//     // element bosilgan div
//     textContent = belgi
//     belgi = '0'
// }
// function unZero() {
//     textContent = belgi
//     belgi = 'x'
// }