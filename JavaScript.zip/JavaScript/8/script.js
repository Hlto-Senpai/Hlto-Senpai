// let TIme = new Date()

// let soat = document.getElementById('soat')
// let minute = document.getElementById('minute')
// let second = document.getElementById('second')

// function clock{

// }
setInterval(function () {element.innerHTML += "Hello"}, 1000);