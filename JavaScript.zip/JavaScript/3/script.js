function foiztopish(x,y){
console.log(x*100/y)
}
foiztopish(50, 100)