function change() {
    
    const input1 = document.getElementById('aa').value
    document.getElementById('bb').value = input1 * 10

} 