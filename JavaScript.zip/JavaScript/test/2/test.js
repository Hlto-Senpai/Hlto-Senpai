function myFunction() {
    var x = document.getElementById("inp").value;
    document.getElementById("h1").innerHTML =  x
}