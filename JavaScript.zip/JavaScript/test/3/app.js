function myFunction(){
    let x = document.getElementById("demo").value
    document.getElementById("content").innerHTML = "Hello, " + x
}