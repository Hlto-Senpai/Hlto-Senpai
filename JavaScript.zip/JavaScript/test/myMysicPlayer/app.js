function next(){
  let y =  document.getElementById("audio1")
    y.setAttribute("src", "music/Miyagi.mp3")
    y.setAttribute("autoplay" , "")

}
function back(){
  let y =  document.getElementById("audio1")
    y.setAttribute("src", "music/Artik.mp3")
    y.setAttribute("autoplay" , "")

}
// function next1(){
//     let y =  document.getElementById("audio1")
//       y.setAttribute("src", "music/fogel.mp3")
//       y.setAttribute("autoplay" , "")
  
//   }

function pause(){
  // let y =  document.getElementById("audio1")
  // document.getElementById("pauseBtn").style.animationPlayState = "pause"
 let stop = document.getElementById("block")
  stop.classList.toggle("btn");
}